const setup = () => {
    document.querySelector('main').classList.remove('d-none');
};

setp();